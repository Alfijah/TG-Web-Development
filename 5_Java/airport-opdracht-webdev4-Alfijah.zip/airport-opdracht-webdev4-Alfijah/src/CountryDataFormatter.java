public class CountryDataFormatter {
//            for (String singleLine : countriesData) {
//            System.out.println(singleLine.replaceAll("[^a-zA-Z0-9]", " "));
//            Pattern p = Pattern.compile("([0-9]+) ([A-Z][A-Z])");
//            Matcher m = p.matcher(singleLine);
//            if (m.find()) {
//                String id = m.group(1);
//                String code = m.group(2);
//                System.out.println(id);
//            }
//        }
}
