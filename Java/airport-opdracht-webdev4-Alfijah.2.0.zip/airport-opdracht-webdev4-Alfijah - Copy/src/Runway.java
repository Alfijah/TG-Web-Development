public class Runway {
    public String id;
    public String airportReference;
    public String airportID;
}
